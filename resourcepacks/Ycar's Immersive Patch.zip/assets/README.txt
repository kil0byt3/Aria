I made this texture pack aiming to unify mods under Immersive Engineering visual identity.
Therefore, some assets (mostly GUIs) are directly taken from Damien "Hazard" work on IE assets. 
Credits to him for his work, and also wp because he's doing amazing things.

Some assets are partially retextured. That means this texture pack is not only my work, but also based
on original mods visuals.
For this reason, credits for each mod retexturing also go to their respective authors and owners.
For any further information, you can contact me on Discord at Ycar#6622

If someone ever reads this file and did go through, well you're a good person.
I mean, at least above average. Cheers.
